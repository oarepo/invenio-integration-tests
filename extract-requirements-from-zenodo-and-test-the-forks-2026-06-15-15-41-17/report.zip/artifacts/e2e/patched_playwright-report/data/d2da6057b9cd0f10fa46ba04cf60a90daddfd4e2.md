# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api/invenio-api.spec.ts >> API Record Tests >> Should create and publish a new metadata-only record
- Location: ../../invenio-e2e/src/fixtures/index.ts:433:19

# Error details

```
Error: apiRequestContext.post: connect ECONNREFUSED 127.0.0.1:443
Call log:
  - → POST https://127.0.0.1/api/records/f4ys9-mep31/draft/actions/publish
    - user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.7827.55 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br
    - X-CSRFToken: eyJhbGciOiJIUzUxMiIsImlhdCI6MTc4MTU0MDIwNywiZXhwIjoxNzgxNjI2NjA3fQ.Imh5MjVMRGNDZE9NZzJucVpMWUprWlF0TkMyc0V0Mm5xIg.6qkfAU0T-7pP0D1xgJXuKXdtMm175KbLHqgmuEr2OI7XffIl4YWZ1TViIn6QyECZucGo3i19ut86jq003rXdTg
    - Referer: https://127.0.0.1:5000
    - cookie: session=d4e873b791750ff2_6a30256f.0IwYlf6nSmwZXIj9k6vhpyYgXBw; csrftoken=eyJhbGciOiJIUzUxMiIsImlhdCI6MTc4MTU0MDIwNywiZXhwIjoxNzgxNjI2NjA3fQ.Imh5MjVMRGNDZE9NZzJucVpMWUprWlF0TkMyc0V0Mm5xIg.6qkfAU0T-7pP0D1xgJXuKXdtMm175KbLHqgmuEr2OI7XffIl4YWZ1TViIn6QyECZucGo3i19ut86jq003rXdTg

```

# Test source

```ts
  136 |     {
  137 |       key: "logo-invenio-rdm.svg",
  138 |       path: "https://inveniordm.docs.cern.ch/images/logo-invenio-rdm.svg",
  139 |       mimetype: "image/svg+xml",
  140 |     },
  141 |     {
  142 |       key: "test.pdf",
  143 |       path: path.resolve(
  144 |         __dirname,
  145 |         "../..",
  146 |         appConfig.dataFolderPath,
  147 |         "api",
  148 |         "test.pdf"
  149 |       ),
  150 |       mimetype: "application/pdf",
  151 |     },
  152 |     { key: "large-file-5mb.dat", path: "", mimetype: "application/octet-stream" }, // This file will be generated on the fly for testing multipart upload with a large file
  153 |   ];
  154 | 
  155 |   const buildRecordObjectMatchers = (
  156 |     defaultRecord: DefaultRecord
  157 |   ): Record<string, unknown> => ({
  158 |     created: expect.any(String),
  159 |     updated: expect.any(String),
  160 |     access: expect.objectContaining({
  161 |       ...defaultRecord.access,
  162 |     }),
  163 |     files: expect.objectContaining({
  164 |       ...defaultRecord.files,
  165 |     }),
  166 |     metadata: expect.objectContaining({
  167 |       ...defaultRecord.metadata,
  168 |       creators: defaultRecord.metadata.creators.map((creator) => {
  169 |         if (creator.person_or_org.type.toLowerCase() === "personal") {
  170 |           return {
  171 |             person_or_org: {
  172 |               ...creator.person_or_org,
  173 |               name: `${creator.person_or_org.family_name}, ${creator.person_or_org.given_name}`,
  174 |             },
  175 |           };
  176 |         }
  177 |         return creator;
  178 |       }),
  179 |       resource_type: expect.objectContaining({
  180 |         ...defaultRecord.metadata.resource_type,
  181 |       }),
  182 |     }),
  183 |   });
  184 | 
  185 |   // Creates a draft record and validates common draft response structure.
  186 |   const createDraftRecord = async (
  187 |     defaultRecord: DefaultRecord,
  188 |     expectFilesLink = false
  189 |   ): Promise<{
  190 |     createdRecord: ApiRecordResponse;
  191 |     recordObjectMatchers: Record<string, unknown>;
  192 |   }> => {
  193 |     const createResponse = await userApiContext.post(recordsApiPath, {
  194 |       data: defaultRecord,
  195 |     });
  196 | 
  197 |     expect(createResponse.status()).toBe(201);
  198 | 
  199 |     const createdRecord = (await createResponse.json()) as ApiRecordResponse;
  200 | 
  201 |     expect(createdRecord, "should not have any errors").not.toHaveProperty("errors");
  202 | 
  203 |     const recordObjectMatchers = buildRecordObjectMatchers(defaultRecord);
  204 | 
  205 |     const draftRecordMatchers: Record<string, unknown> = {
  206 |       id: expect.any(String),
  207 |       status: "draft",
  208 |       is_published: false,
  209 |       is_draft: true,
  210 |       ...recordObjectMatchers,
  211 |     };
  212 | 
  213 |     if (expectFilesLink) {
  214 |       draftRecordMatchers.links = expect.objectContaining({
  215 |         files: expect.any(String),
  216 |       });
  217 |     }
  218 | 
  219 |     expect(createdRecord, "should be a draft and match the expected structure").toEqual(
  220 |       expect.objectContaining(draftRecordMatchers)
  221 |     );
  222 | 
  223 |     return {
  224 |       createdRecord,
  225 |       recordObjectMatchers,
  226 |     };
  227 |   };
  228 | 
  229 |   // Publishes a draft record and validates the final published representation.
  230 |   const publishAndVerifyRecord = async (
  231 |     createdRecord: ApiRecordResponse,
  232 |     recordObjectMatchers: Record<string, unknown>
  233 |   ) => {
  234 |     // Publish the record
  235 |     /* eslint-disable @typescript-eslint/no-unsafe-argument, @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-assignment */
> 236 |     const publishResponse = await userApiContext.post(createdRecord.links?.publish);
      |                                                  ^ Error: apiRequestContext.post: connect ECONNREFUSED 127.0.0.1:443
  237 | 
  238 |     expect(publishResponse.status()).toBe(202);
  239 | 
  240 |     const publishedRecord = await publishResponse.json();
  241 | 
  242 |     expect(publishedRecord, "should not have any errors").not.toHaveProperty("errors");
  243 |     expect(
  244 |       publishedRecord,
  245 |       "should be published and match the expected structure"
  246 |     ).toEqual(
  247 |       expect.objectContaining({
  248 |         id: createdRecord.id,
  249 |         status: "published",
  250 |         is_published: true,
  251 |         is_draft: false,
  252 |         ...recordObjectMatchers,
  253 |       })
  254 |     );
  255 | 
  256 |     // Verify the record is published
  257 |     const record = await userApiContext.get(publishedRecord.links?.self);
  258 | 
  259 |     expect(record.status()).toBe(200);
  260 | 
  261 |     const recordData = (await record.json()) as ApiRecordResponse;
  262 | 
  263 |     expect(
  264 |       recordData,
  265 |       "should return again the published record with correct structure"
  266 |     ).toEqual(
  267 |       expect.objectContaining({
  268 |         id: createdRecord.id,
  269 |         status: "published",
  270 |         is_published: true,
  271 |         is_draft: false,
  272 |         ...recordObjectMatchers,
  273 |         created: publishedRecord.created, // created timestamp should be the same as when published
  274 |         updated: publishedRecord.updated, // updated timestamp should be the same as when published
  275 |       })
  276 |     );
  277 |     /* eslint-enable @typescript-eslint/no-unsafe-argument, @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-assignment */
  278 |     return recordData;
  279 |   };
  280 | 
  281 |   const uploadFileWithLocalTransfer = async (
  282 |     createdRecord: ApiRecordResponse,
  283 |     file: FileUploadDescriptor
  284 |   ) => {
  285 |     // File upload process (https://inveniordm.docs.cern.ch/reference/file_transfer/)
  286 |     /*
  287 |             1. Start draft file upload (POST /api/records/draft/{id}/files)
  288 |             2. Upload file content (PUT to the 'content' link from previous step)
  289 |             3. Commit file upload (POST to the 'commit' link from step 1)
  290 |         */
  291 | 
  292 |     // Start draft file upload https://inveniordm.docs.cern.ch/reference/rest_api_drafts_records/#start-draft-file-uploads
  293 |     const startFilesUploadResponse = await userApiContext.post(
  294 |       createdRecord.links.files,
  295 |       {
  296 |         data: [{ key: file.key }],
  297 |       }
  298 |     );
  299 | 
  300 |     expect(startFilesUploadResponse.status()).toBe(201);
  301 | 
  302 |     const startFilesUploadData =
  303 |       (await startFilesUploadResponse.json()) as StartUploadResponse;
  304 | 
  305 |     expect(startFilesUploadData, "should be pending and have links section").toEqual(
  306 |       expect.objectContaining({
  307 |         entries: expect.arrayContaining([
  308 |           expect.objectContaining({
  309 |             key: file.key,
  310 |             status: "pending",
  311 |             links: expect.objectContaining({
  312 |               content: expect.any(String),
  313 |               self: expect.any(String),
  314 |               commit: expect.any(String),
  315 |             }),
  316 |           }),
  317 |         ]),
  318 |       })
  319 |     );
  320 | 
  321 |     // Upload file content
  322 |     const fileContent = readFileSync(file.path);
  323 | 
  324 |     const contentUrl = startFilesUploadData.entries[0]?.links.content;
  325 |     expect(
  326 |       contentUrl,
  327 |       `content upload link should exist for ${file.key}`
  328 |     ).toBeDefined();
  329 | 
  330 |     const fileUploadResponse = await userApiContext.put(contentUrl!, {
  331 |       headers: {
  332 |         "Content-Type": "application/octet-stream",
  333 |       },
  334 |       data: fileContent,
  335 |     });
  336 | 
```