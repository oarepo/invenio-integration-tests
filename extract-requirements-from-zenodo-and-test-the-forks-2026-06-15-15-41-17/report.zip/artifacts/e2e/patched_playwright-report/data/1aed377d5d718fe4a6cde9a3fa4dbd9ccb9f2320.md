# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api/invenio-api.spec.ts >> API Record Tests >> Should create and publish a new record with multipart file upload transfer (two parts)
- Location: ../../invenio-e2e/src/fixtures/index.ts:433:19

# Error details

```
Error: apiRequestContext.post: connect ECONNREFUSED 127.0.0.1:443
Call log:
  - → POST https://127.0.0.1/api/records/9mb37-4we83/draft/files
    - user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.7827.55 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br
    - X-CSRFToken: eyJhbGciOiJIUzUxMiIsImlhdCI6MTc4MTU0MDIwNywiZXhwIjoxNzgxNjI2NjA3fQ.Imh5MjVMRGNDZE9NZzJucVpMWUprWlF0TkMyc0V0Mm5xIg.6qkfAU0T-7pP0D1xgJXuKXdtMm175KbLHqgmuEr2OI7XffIl4YWZ1TViIn6QyECZucGo3i19ut86jq003rXdTg
    - Referer: https://127.0.0.1:5000
    - content-type: application/json
    - content-length: 79
    - cookie: session=d4e873b791750ff2_6a30256f.0IwYlf6nSmwZXIj9k6vhpyYgXBw; csrftoken=eyJhbGciOiJIUzUxMiIsImlhdCI6MTc4MTU0MDIwNywiZXhwIjoxNzgxNjI2NjA3fQ.Imh5MjVMRGNDZE9NZzJucVpMWUprWlF0TkMyc0V0Mm5xIg.6qkfAU0T-7pP0D1xgJXuKXdtMm175KbLHqgmuEr2OI7XffIl4YWZ1TViIn6QyECZucGo3i19ut86jq003rXdTg

```

# Test source

```ts
  389 |     const startFetchUploadData =
  390 |       (await startFetchUploadResponse.json()) as StartUploadResponse;
  391 | 
  392 |     expect(
  393 |       startFetchUploadData,
  394 |       `file ${file.key} should be pending with fetch method`
  395 |     ).toEqual(
  396 |       expect.objectContaining({
  397 |         entries: expect.arrayContaining([
  398 |           expect.objectContaining({
  399 |             key: file.key,
  400 |             status: expect.stringMatching(/pending|completed/), // Depending on timing, the transfer might already be completed
  401 |             transfer: {
  402 |               type: "F",
  403 |             },
  404 |             links: expect.objectContaining({
  405 |               content: expect.any(String),
  406 |               self: expect.any(String),
  407 |               commit: expect.any(String),
  408 |             }),
  409 |           }),
  410 |         ]),
  411 |       })
  412 |     );
  413 | 
  414 |     const fetchedFileEntry = startFetchUploadData.entries.find(
  415 |       (entry) => entry.key === file.key
  416 |     );
  417 | 
  418 |     if (fetchedFileEntry?.status !== "completed") {
  419 |       // Wait for the file to be fetched by polling the 'self' link until the status becomes 'completed'
  420 |       await expect
  421 |         .poll(
  422 |           async () => {
  423 |             const response = await adminApiContext.get(fetchedFileEntry!.links.self);
  424 |             if (response.status() !== 200) return false;
  425 |             const data = (await response.json()) as { status?: string };
  426 |             if (data.status === "completed") return true;
  427 |             return false;
  428 |           },
  429 |           {
  430 |             message: `file transfer of ${file.key} should be completed`,
  431 |             intervals: [1000, 3000, 6000, 15000], // Polling intervals in milliseconds
  432 |           }
  433 |         )
  434 |         .toBe(true);
  435 |     }
  436 | 
  437 |     // Commit the fetched file
  438 |     const commitFetchResponse = await adminApiContext.post(
  439 |       fetchedFileEntry!.links.commit
  440 |     );
  441 | 
  442 |     expect(commitFetchResponse.status()).toBe(200);
  443 | 
  444 |     const committedFetchData = (await commitFetchResponse.json()) as Record<
  445 |       string,
  446 |       unknown
  447 |     >;
  448 | 
  449 |     // To verify the checksum, fetch the original file and compute the digest locally.
  450 |     // With Fetch transfer, the server downloads the file directly, so we do not have the
  451 |     // upload payload available in the test process before commit.
  452 |     const remoteFileResponse = await fetch(file.path);
  453 |     const remoteFileStream = Readable.fromWeb(
  454 |       remoteFileResponse.body as ReadableStream
  455 |     );
  456 |     const fetchFileChecksumHash = crypto.createHash("md5");
  457 |     for await (const chunk of remoteFileStream) {
  458 |       fetchFileChecksumHash.update(chunk as Buffer);
  459 |     }
  460 |     const fetchFileChecksum = fetchFileChecksumHash.digest("hex");
  461 | 
  462 |     expect(
  463 |       committedFetchData,
  464 |       `commit of ${file.key} should be completed with valid checksum`
  465 |     ).toEqual(
  466 |       expect.objectContaining({
  467 |         key: file.key,
  468 |         status: "completed",
  469 |         transfer: {
  470 |           type: "L",
  471 |         },
  472 |         mimetype: file.mimetype,
  473 |         size: expect.any(Number),
  474 |         checksum: `md5:${fetchFileChecksum}`,
  475 |       })
  476 |     );
  477 |   };
  478 | 
  479 |   const uploadFileWithMultipartTransfer = async (
  480 |     createdRecord: ApiRecordResponse,
  481 |     file: FileUploadDescriptor,
  482 |     partsCount: number,
  483 |     fileBuffer?: Buffer
  484 |   ) => {
  485 |     // For generated files, `fileBuffer` is used; otherwise file contents are read from disk.
  486 |     const multipartFileContent = fileBuffer ?? readFileSync(file.path);
  487 | 
  488 |     // Start multipart upload
> 489 |     const startMultipartTransferResponse = await userApiContext.post(
      |                                                                 ^ Error: apiRequestContext.post: connect ECONNREFUSED 127.0.0.1:443
  490 |       createdRecord.links.files,
  491 |       {
  492 |         data: [
  493 |           {
  494 |             key: file.key,
  495 |             size: multipartFileContent.length,
  496 |             transfer: {
  497 |               type: "M",
  498 |               parts: partsCount,
  499 |             },
  500 |           },
  501 |         ],
  502 |       }
  503 |     );
  504 | 
  505 |     expect(startMultipartTransferResponse.status()).toBe(201);
  506 | 
  507 |     const startMultipartTransferData =
  508 |       (await startMultipartTransferResponse.json()) as StartUploadResponse;
  509 | 
  510 |     expect(
  511 |       startMultipartTransferData,
  512 |       `file ${file.key} should be pending with multipart method`
  513 |     ).toEqual(
  514 |       expect.objectContaining({
  515 |         entries: expect.arrayContaining([
  516 |           expect.objectContaining({
  517 |             key: file.key,
  518 |             status: "pending",
  519 |             transfer: {
  520 |               type: "M",
  521 |               parts: partsCount,
  522 |             },
  523 |             links: expect.objectContaining({
  524 |               parts: expect.arrayContaining([
  525 |                 expect.objectContaining({
  526 |                   part: expect.any(Number),
  527 |                   url: expect.any(String),
  528 |                 }),
  529 |               ]),
  530 |               self: expect.any(String),
  531 |               commit: expect.any(String),
  532 |             }),
  533 |           }),
  534 |         ]),
  535 |       })
  536 |     );
  537 | 
  538 |     const multipartEntry = startMultipartTransferData.entries.find(
  539 |       (entry) => entry.key === file.key
  540 |     );
  541 |     expect(multipartEntry, `expected upload entry for ${file.key}`).toBeDefined();
  542 |     const partLinks = multipartEntry!.links.parts ?? [];
  543 | 
  544 |     expect(partLinks.length, `should have ${partsCount} parts as specified`).toBe(
  545 |       partsCount
  546 |     );
  547 | 
  548 |     const uploadPart = async (partUrl: string, data: Buffer) => {
  549 |       const response = await userApiContext.put(partUrl, {
  550 |         headers: {
  551 |           "Content-Type": "application/octet-stream",
  552 |         },
  553 |         data,
  554 |       });
  555 |       return response;
  556 |     };
  557 | 
  558 |     const partsUploadResponses = await Promise.all(
  559 |       partLinks.map((part, index) => {
  560 |         // Split the file into S3_DEFAULT_BLOCK_SIZE chunks, keeping the remainder in the last part.
  561 |         const partStart = index * appConfig.s3DefaultBlockSize;
  562 |         const partEnd =
  563 |           index === partLinks.length - 1
  564 |             ? multipartFileContent.length
  565 |             : Math.min(
  566 |                 (index + 1) * appConfig.s3DefaultBlockSize,
  567 |                 multipartFileContent.length
  568 |               );
  569 |         const partData = multipartFileContent.subarray(partStart, partEnd);
  570 |         return uploadPart(part.url, partData);
  571 |       })
  572 |     );
  573 | 
  574 |     for (let i = 0; i < partsUploadResponses.length; i++) {
  575 |       expect(
  576 |         partsUploadResponses[i].status(),
  577 |         `upload of part ${i + 1} should be successful`
  578 |       ).toBe(200);
  579 |     }
  580 | 
  581 |     const commitMultipartResponse = await userApiContext.post(
  582 |       multipartEntry!.links.commit
  583 |     );
  584 | 
  585 |     expect(commitMultipartResponse.status()).toBe(200);
  586 | 
  587 |     // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
  588 |     const commitMultipartData = await commitMultipartResponse.json();
  589 | 
```